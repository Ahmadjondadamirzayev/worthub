import React, { createContext, useContext, useState, useEffect } from 'react';

export type Language = 'uz' | 'ru' | 'en';

export interface LanguageOption {
  code: Language;
  name: string;
  nativeName: string;
  flag: string;
}

export const SUPPORTED_LANGUAGES: LanguageOption[] = [
  { code: 'uz', name: "O'zbekcha", nativeName: "O'zbek", flag: '🇺🇿' },
  { code: 'ru', name: 'Русский', nativeName: 'Русский', flag: '🇷🇺' },
  { code: 'en', name: 'English', nativeName: 'English', flag: '🇬🇧' },
];

export const translations = {
  uz: {
    // TopNav & Header
    nav_lessons: "Lektionlar To'plami",
    nav_lessons_badge: "Darslar",
    nav_games: "O'yinlar & Grammatika",
    nav_leaderboard: "O'quvchilar reytingi",
    nav_app: "Ilova",
    nav_add_user: "+ Odam qo'shish",
    nav_admin: "Admin",
    nav_logout: "Tizimdan chiqish",
    nav_language: "Til",
    nav_user: "Foydalanuvchi",

    // Common
    save: "Saqlash",
    cancel: "Bekor qilish",
    delete: "O'chirish",
    edit: "Tahrirlash",
    add: "Qo'shish",
    search: "Qidirish...",
    all: "Barchasi",
    active: "Faol",
    inactive: "Nofaol",
    close: "Yopish",
    back: "Orqaga",
    loading: "Yuklanmoqda...",
    success: "Muvaffaqiyatli",
    error: "Xatolik",
    copy: "Nusxa olish",
    download: "Yuklab olish",
    import: "Import",
    export: "Eksport",
    start: "Boshlash",
    finish: "Yakunlash",
    next: "Keyingisi",
    correct: "To'g'ri",
    incorrect: "Noto'g'ri",
    score: "Ball",
    level: "Daraja",
    words_count: "So'zlar soni",
    listen: "Tinglash",

    // Login View
    login_title: "Worthub.uz ga xush kelibsiz",
    login_subtitle: "Nemis tilini professional darajada o'rganish platformasi",
    login_tab_login: "Tizimga kirish",
    login_tab_apply: "O'qishga ariza topshirish",
    login_username: "Foydalanuvchi nomi (Login)",
    login_username_placeholder: "masalan: ahmadjon yoki jasur",
    login_password: "Maxfiy parol",
    login_password_placeholder: "Parolni kiriting...",
    login_btn: "Tizimga kirish",
    login_demo_title: "Tayyor hisoblar (Demo kirish):",
    login_teacher: "O'qituvchi / Admin",
    login_student: "O'quvchi",
    login_error_invalid: "Foydalanuvchi nomi yoki parol noto'g'ri!",
    login_error_empty: "Iltimos, login va parolni kiriting!",
    login_error_inactive: "Ushbu hisob faolsizlantirilgan. O'qituvchi bilan bog'laning.",
    apply_title: "Nemis tili guruhiga yozilish",
    apply_desc: "Ma'lumotlaringizni qoldiring, o'qituvchi siz bilan bog'lanadi va hisob ochib beradi.",
    apply_name: "Ism va Familiyangiz",
    apply_name_placeholder: "To'liq ismingizni yozing...",
    apply_phone: "Telefon raqamingiz",
    apply_phone_placeholder: "+998 90 123 45 67",
    apply_level: "Hozirgi nemis tili darajangiz",
    apply_btn: "Arizani yuborish",
    apply_success_title: "Arizangiz qabul qilindi!",
    apply_success_desc: "Tez orada o'qituvchi siz bilan bog'lanadi va shaxsiy akkaunt taqdim etiladi.",
    apply_back_btn: "Kirish oynasiga qaytish",

    // Lektionen View
    lek_badge: "BLITZ NEMIS TILI MARKAZI",
    lek_title: "Nemis tili lektionlari va so'z boyligi",
    lek_desc: "Har bir mavzu bo'yicha saralangan so'zlar, artikllar (der/die/das), ko'plik shakllari va o'zbekcha tarjimalari.",
    lek_search_placeholder: "So'z yoki tarjima qidirish...",
    lek_level_filter: "Daraja",
    lek_all_levels: "Barcha darajalar",
    lek_total_words: "Jami so'zlar",
    lek_active_words: "Faol so'zlar",
    lek_learned_words: "O'rganilgan",
    lek_add_word_btn: "Yangi so'z qo'shish",
    lek_import_btn: "Import (PDF / TXT)",
    lek_practice_btn: "Mashq qilish",
    lek_flashcards_btn: "Kartochkalar",
    lek_word_singular: "So'z",
    lek_article: "Artikl",
    lek_plural: "Ko'plik",
    lek_translation: "Tarjima",
    lek_example: "Misol",
    lek_notes: "Qo'shimcha izoh",
    lek_no_words_found: "Ushbu darsda so'zlar topilmadi",
    lek_lesson_completed: "Tugallangan",
    lek_lesson_in_progress: "Jarayonda",

    // Games Hub View
    games_badge: "INTERAKTIV TRENAJER",
    games_title: "O'yinlar va Treninglar Markazi",
    games_desc: "So'zlarni yodlash, artikllarni mustahkamlash, imlo va grammatika bo'yicha interaktiv o'yinlar.",
    games_level_filter: "CEFR Darajasi:",
    games_lesson_filter: "Dars bo'yicha:",
    games_all_lessons: "Barcha darslar",
    games_words_pool: "Tanlangan so'zlar:",
    games_back_btn: "Barcha o'yinlarga qaytish",

    // Specific Games
    game_super_title: "Super Yodlash",
    game_super_desc: "Flashkartalar yordamida tezkor takrorlash va talaffuzni tinglash",
    game_artikel_title: "Artikel Meister",
    game_artikel_desc: "Der, Die, Das artikllarini chaqqonlik bilan to'g'ri topish",
    game_paare_title: "Wort-Paare",
    game_paare_desc: "Nemischa so'z va uning tarjimasi juftliklarini birlashtirish",
    game_blitz_title: "Blitz Wort",
    game_blitz_desc: "Tezkor vaqt ichida to'g'ri tarjimani tanlash",
    game_buchstaben_title: "Buchstabensalat",
    game_buchstaben_desc: "Aralashib ketgan harflardan to'g'ri nemischa so'zni yig'ish",
    game_quiz_title: "Wort Quiz",
    game_quiz_desc: "4 ta variantdan to'g'risini topish viktorinasi",
    game_kasus_title: "Kasus Trainer",
    game_kasus_desc: "Nominativ, Akkusativ, Dativ kelishiklarini mustahkamlash",
    game_verb_title: "Verb Konjugation",
    game_verb_desc: "Fe'llarni shaxslar bo'yicha tuslash mashqi",
    game_satzbau_title: "Satzbau Profi",
    game_satzbau_desc: "Gap bo'laklaridan grammatik to'g'ri gap tuzish",

    // Leaderboard View
    lead_badge: "WORTHUB.UZ O'QUVCHILAR LIGASI",
    lead_title: "O'quvchilar reytingi va ballar jadvali",
    lead_desc: "Nemis tili darslari, o'yinlardagi faollik va o'zlashtirilgan so'zlar bo'yicha yetakchilar ro'yxati.",
    lead_rank: "O'rin",
    lead_student: "O'quvchi",
    lead_level: "Daraja",
    lead_score: "Jami Ball (XP)",
    lead_streak: "Ketma-ketlik (Kun)",
    lead_words: "Yodlangan so'zlar",
    lead_add_btn: "+ Yangi o'quvchi qo'shish",
    lead_games_btn: "O'yinlarga o'tish",

    // Admin & Modals
    admin_title: "O'qituvchi Boshqaruv Paneli",
    admin_tab_students: "O'quvchilar",
    admin_tab_lessons: "Lektionlar & So'zlar",
    admin_tab_apps: "Arizalar",
    admin_tab_git: "Git & Kodni yuklab olish",
    admin_tab_sessions: "Seanslar",

    // Footer
    footer_tagline: "Nemis tili so'z boyligi va interaktiv o'yinlar portali",
    footer_user_prefix: "Foydalanuvchi:",
    footer_teacher: "O'qituvchi",
    footer_level: "Daraja",
  },

  ru: {
    // TopNav & Header
    nav_lessons: "Коллекция уроков",
    nav_lessons_badge: "Уроки",
    nav_games: "Игры и грамматика",
    nav_leaderboard: "Рейтинг учеников",
    nav_app: "Приложение",
    nav_add_user: "+ Добавить ученика",
    nav_admin: "Админ",
    nav_logout: "Выйти из системы",
    nav_language: "Язык",
    nav_user: "Пользователь",

    // Common
    save: "Сохранить",
    cancel: "Отмена",
    delete: "Удалить",
    edit: "Редактировать",
    add: "Добавить",
    search: "Поиск...",
    all: "Все",
    active: "Активен",
    inactive: "Неактивен",
    close: "Закрыть",
    back: "Назад",
    loading: "Загрузка...",
    success: "Успешно",
    error: "Ошибка",
    copy: "Копировать",
    download: "Скачать",
    import: "Импорт",
    export: "Экспорт",
    start: "Начать",
    finish: "Завершить",
    next: "Следующий",
    correct: "Верно",
    incorrect: "Неверно",
    score: "Баллы",
    level: "Уровень",
    words_count: "Количество слов",
    listen: "Слушать",

    // Login View
    login_title: "Добро пожаловать в Worthub.uz",
    login_subtitle: "Профессиональная платформа для изучения немецкого языка",
    login_tab_login: "Вход в систему",
    login_tab_apply: "Подать заявку на обучение",
    login_username: "Имя пользователя (Логин)",
    login_username_placeholder: "например: ahmadjon или jasur",
    login_password: "Пароль",
    login_password_placeholder: "Введите пароль...",
    login_btn: "Войти в систему",
    login_demo_title: "Готовые аккаунты (Демо-вход):",
    login_teacher: "Преподаватель / Админ",
    login_student: "Ученик",
    login_error_invalid: "Неверное имя пользователя или пароль!",
    login_error_empty: "Пожалуйста, введите логин и пароль!",
    login_error_inactive: "Этот аккаунт деактивирован. Обратитесь к преподавателю.",
    apply_title: "Запись на курс немецкого языка",
    apply_desc: "Оставьте свои данные, преподаватель свяжется с вами и откроет аккаунт.",
    apply_name: "Имя и Фамилия",
    apply_name_placeholder: "Введите полное имя...",
    apply_phone: "Номер телефона",
    apply_phone_placeholder: "+998 90 123 45 67",
    apply_level: "Текущий уровень немецкого",
    apply_btn: "Отправить заявку",
    apply_success_title: "Заявка успешно принята!",
    apply_success_desc: "Преподаватель скоро свяжется с вами и предоставит доступ.",
    apply_back_btn: "Вернуться к экрану входа",

    // Lektionen View
    lek_badge: "BLITZ NEMIS TILI MARKAZI",
    lek_title: "Уроки немецкого и словарный запас",
    lek_desc: "Слова по темам с артиклями (der/die/das), формами множественного числа и переводами.",
    lek_search_placeholder: "Поиск слова или перевода...",
    lek_level_filter: "Уровень",
    lek_all_levels: "Все уровни",
    lek_total_words: "Всего слов",
    lek_active_words: "Активные слова",
    lek_learned_words: "Изучено",
    lek_add_word_btn: "Добавить слово",
    lek_import_btn: "Импорт (PDF / TXT)",
    lek_practice_btn: "Тренировка",
    lek_flashcards_btn: "Карточки",
    lek_word_singular: "Слово",
    lek_article: "Артикль",
    lek_plural: "Множественное число",
    lek_translation: "Перевод",
    lek_example: "Пример",
    lek_notes: "Примечание",
    lek_no_words_found: "В этом уроке слова не найдены",
    lek_lesson_completed: "Завершено",
    lek_lesson_in_progress: "В процессе",

    // Games Hub View
    games_badge: "ИНТЕРАКТИВНЫЙ ТРЕНАЖЁР",
    games_title: "Центр Игр и Тренажёров",
    games_desc: "Интерактивные игры для запоминания слов, отработки артиклей, правописания и грамматики.",
    games_level_filter: "Уровень CEFR:",
    games_lesson_filter: "По уроку:",
    games_all_lessons: "Все уроки",
    games_words_pool: "Выбрано слов:",
    games_back_btn: "Вернуться ко всем играм",

    // Specific Games
    game_super_title: "Супер Запоминание",
    game_super_desc: "Быстрое повторение карточек и прослушивание произношения",
    game_artikel_title: "Мастер Артиклей",
    game_artikel_desc: "Быстрое и точное определение артиклей Der, Die, Das",
    game_paare_title: "Пары Слов",
    game_paare_desc: "Соединение немецкого слова и его перевода",
    game_blitz_title: "Блиц Слово",
    game_blitz_desc: "Выбор правильного перевода на скорость",
    game_buchstaben_title: "Салат из Букв",
    game_buchstaben_desc: "Сборка правильного немецкого слова из перемешанных букв",
    game_quiz_title: "Словарная Викторина",
    game_quiz_desc: "Викторина с выбором из 4 вариантов ответов",
    game_kasus_title: "Тренажёр Падежей",
    game_kasus_desc: "Отработка падежей Nominativ, Akkusativ, Dativ",
    game_verb_title: "Спряжение Глаголов",
    game_verb_desc: "Тренировка спряжения глаголов по лицам",
    game_satzbau_title: "Мастер Предложений",
    game_satzbau_desc: "Составление грамматически верных предложений из частей",

    // Leaderboard View
    lead_badge: "ЛИГА УЧЕНИКОВ WORTHUB.UZ",
    lead_title: "Рейтинг учеников и таблица очков",
    lead_desc: "Список лидеров по урокам немецкого языка, активности в играх и выученным словам.",
    lead_rank: "Место",
    lead_student: "Ученик",
    lead_level: "Уровень",
    lead_score: "Очки (XP)",
    lead_streak: "Серия (Дни)",
    lead_words: "Выучено слов",
    lead_add_btn: "+ Добавить ученика",
    lead_games_btn: "Перейти к играм",

    // Admin & Modals
    admin_title: "Панель управления преподавателя",
    admin_tab_students: "Ученики",
    admin_tab_lessons: "Уроки и слова",
    admin_tab_apps: "Заявки",
    admin_tab_git: "Синхронизация Git",
    admin_tab_sessions: "Сеансы",

    // Footer
    footer_tagline: "Портал немецкого словарного запаса и интерактивных игр",
    footer_user_prefix: "Пользователь:",
    footer_teacher: "Преподаватель",
    footer_level: "Уровень",
  },

  en: {
    // TopNav & Header
    nav_lessons: "Lesson Collection",
    nav_lessons_badge: "Lessons",
    nav_games: "Games & Grammar",
    nav_leaderboard: "Leaderboard",
    nav_app: "App",
    nav_add_user: "+ Add Student",
    nav_admin: "Admin",
    nav_logout: "Log out",
    nav_language: "Language",
    nav_user: "User",

    // Common
    save: "Save",
    cancel: "Cancel",
    delete: "Delete",
    edit: "Edit",
    add: "Add",
    search: "Search...",
    all: "All",
    active: "Active",
    inactive: "Inactive",
    close: "Close",
    back: "Back",
    loading: "Loading...",
    success: "Success",
    error: "Error",
    copy: "Copy",
    download: "Download",
    import: "Import",
    export: "Export",
    start: "Start",
    finish: "Finish",
    next: "Next",
    correct: "Correct",
    incorrect: "Incorrect",
    score: "Score",
    level: "Level",
    words_count: "Words count",
    listen: "Listen",

    // Login View
    login_title: "Welcome to Worthub.uz",
    login_subtitle: "Professional German language learning platform",
    login_tab_login: "Sign in",
    login_tab_apply: "Apply for Course",
    login_username: "Username (Login)",
    login_username_placeholder: "e.g., ahmadjon or jasur",
    login_password: "Password",
    login_password_placeholder: "Enter password...",
    login_btn: "Sign in",
    login_demo_title: "Demo Accounts:",
    login_teacher: "Teacher / Admin",
    login_student: "Student",
    login_error_invalid: "Invalid username or password!",
    login_error_empty: "Please enter username and password!",
    login_error_inactive: "This account has been deactivated. Please contact your instructor.",
    apply_title: "Enroll in German Language Course",
    apply_desc: "Leave your details and the teacher will contact you to create an account.",
    apply_name: "Full Name",
    apply_name_placeholder: "Enter your full name...",
    apply_phone: "Phone Number",
    apply_phone_placeholder: "+998 90 123 45 67",
    apply_level: "Current German Level",
    apply_btn: "Submit Application",
    apply_success_title: "Application Received!",
    apply_success_desc: "The teacher will contact you shortly to provide your account credentials.",
    apply_back_btn: "Back to Login",

    // Lektionen View
    lek_badge: "BLITZ NEMIS TILI MARKAZI",
    lek_title: "German Lessons & Vocabulary",
    lek_desc: "Topic-organized vocabulary with articles (der/die/das), plurals, and Uzbek translations.",
    lek_search_placeholder: "Search word or translation...",
    lek_level_filter: "Level",
    lek_all_levels: "All Levels",
    lek_total_words: "Total Words",
    lek_active_words: "Active Words",
    lek_learned_words: "Learned",
    lek_add_word_btn: "Add Word",
    lek_import_btn: "Import (PDF / TXT)",
    lek_practice_btn: "Practice",
    lek_flashcards_btn: "Flashcards",
    lek_word_singular: "Word",
    lek_article: "Article",
    lek_plural: "Plural",
    lek_translation: "Translation",
    lek_example: "Example",
    lek_notes: "Notes",
    lek_no_words_found: "No words found in this lesson",
    lek_lesson_completed: "Completed",
    lek_lesson_in_progress: "In Progress",

    // Games Hub View
    games_badge: "INTERACTIVE TRAINER",
    games_title: "Games & Practice Hub",
    games_desc: "Interactive games for vocabulary retention, articles mastery, spelling, and grammar.",
    games_level_filter: "CEFR Level:",
    games_lesson_filter: "By Lesson:",
    games_all_lessons: "All Lessons",
    games_words_pool: "Selected words:",
    games_back_btn: "Back to All Games",

    // Specific Games
    game_super_title: "Super Flashcards",
    game_super_desc: "Fast flashcard revision and audio pronunciation playback",
    game_artikel_title: "Artikel Meister",
    game_artikel_desc: "Quickly match Der, Die, Das articles correctly",
    game_paare_title: "Word Pairs",
    game_paare_desc: "Match German words with their translations",
    game_blitz_title: "Blitz Word",
    game_blitz_desc: "Fast-paced multiple choice translation challenge against time",
    game_buchstaben_title: "Letter Scramble",
    game_buchstaben_desc: "Unscramble mixed letters to assemble the correct German word",
    game_quiz_title: "Word Quiz",
    game_quiz_desc: "4-option multiple-choice vocabulary quiz",
    game_kasus_title: "Case Trainer",
    game_kasus_desc: "Practice Nominativ, Akkusativ, and Dativ cases",
    game_verb_title: "Verb Conjugation",
    game_verb_desc: "Conjugate German verbs across person forms",
    game_satzbau_title: "Sentence Builder",
    game_satzbau_desc: "Arrange words into grammatically correct German sentences",

    // Leaderboard View
    lead_badge: "WORTHUB.UZ STUDENT LEAGUE",
    lead_title: "Student Leaderboard & Scores",
    lead_desc: "Leaderboard based on German lessons completed, game activity, and learned words.",
    lead_rank: "Rank",
    lead_student: "Student",
    lead_level: "Level",
    lead_score: "Total Points (XP)",
    lead_streak: "Streak (Days)",
    lead_words: "Learned Words",
    lead_add_btn: "+ Add Student",
    lead_games_btn: "Go to Games",

    // Admin & Modals
    admin_title: "Teacher Admin Panel",
    admin_tab_students: "Students",
    admin_tab_lessons: "Lessons & Words",
    admin_tab_apps: "Applications",
    admin_tab_git: "Git Sync & Download",
    admin_tab_sessions: "Sessions",

    // Footer
    footer_tagline: "German vocabulary and interactive games learning portal",
    footer_user_prefix: "User:",
    footer_teacher: "Teacher",
    footer_level: "Level",
  },
} as const;

export type TranslationKey = keyof typeof translations['uz'];

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: TranslationKey, fallback?: string) => string;
}

const LanguageContext = createContext<LanguageContextType>({
  language: 'uz',
  setLanguage: () => {},
  t: (key) => key,
});

const LANGUAGE_STORAGE_KEY = 'worthub_language_v1';

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    try {
      const stored = localStorage.getItem(LANGUAGE_STORAGE_KEY) as Language | null;
      if (stored === 'uz' || stored === 'ru' || stored === 'en') {
        return stored;
      }
    } catch (e) {
      // ignore
    }
    return 'uz';
  });

  const setLanguage = (newLang: Language) => {
    setLanguageState(newLang);
    try {
      localStorage.setItem(LANGUAGE_STORAGE_KEY, newLang);
      document.documentElement.lang = newLang;
    } catch (e) {
      // ignore
    }
  };

  useEffect(() => {
    document.documentElement.lang = language;
  }, [language]);

  const t = (key: TranslationKey, fallback?: string): string => {
    const langDict = translations[language] as Record<string, string>;
    if (langDict && langDict[key]) {
      return langDict[key];
    }
    const uzDict = translations.uz as Record<string, string>;
    if (uzDict && uzDict[key]) {
      return uzDict[key];
    }
    return fallback || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => useContext(LanguageContext);
